# JARVIS v3 build / security report

This release hardens v2 against the audit findings while retaining the existing six-tool agent architecture.

Implemented:
- Private HttpOnly session authentication via `/api/auth`.
- Same-origin enforcement and per-route in-memory rate limits.
- Body-size limits for auth/chat/TTS.
- Abort propagation from chat requests into the agent and external tools.
- Browser URL allowlisting with HTTPS-only, no credentials, no IP literals, and no custom ports.
- Bounded Tavily and Browserless responses.
- Calculator rewritten as a small parser; no `Function()` or `eval`.
- Local memory bounded by count and serialized size; sent back as request-scoped agent call options.
- Explicit voice opt-in and audio URL cleanup.
- SpeechRecognition cleanup and stale-status protection.
- Retryable chat error state.
- Security response headers and Vercel Node engine declaration.
- Node built-in regression tests for calculator + session signing.

Important:
- AI SDK 7 currently documents `stepCountIs`, so the audit's C1 finding claiming it was renamed to `isStepCount` was incorrect. The v3 code intentionally keeps `stepCountIs`.
- Full `npm install`/`next build` was still blocked in this sandbox by an external network/package-install timeout. `npm test` can run without third-party packages because the security/calculator tests use only Node built-ins.
- The in-memory rate limiter is per runtime instance, not globally distributed. For a public high-traffic deployment, add Vercel Firewall / a distributed limiter such as Upstash.
- Browserless is intentionally allowlisted. Add domains to `BROWSER_ALLOWED_DOMAINS` rather than opening arbitrary URLs.
