# JARVIS Assistant v3

Private, Vercel-ready JARVIS-style AI assistant built with Next.js and the Vercel AI SDK.

## Capabilities

- Gemini-powered autonomous `ToolLoopAgent`
- Tavily live web search
- Browserless rendered-page browsing with an HTTPS allowlist
- Exact calculator with no `eval`/`Function`
- Asia/Kolkata time tool
- Explicit local-memory save/retrieval context
- Optional ElevenLabs voice output
- Browser speech input
- Streaming agent responses

## Environment

Copy `.env.example` to `.env.local` and configure:

- `GEMINI_API_KEY`
- `TAVILY_API_KEY`
- `BROWSERLESS_TOKEN`
- `BROWSER_ALLOWED_DOMAINS`
- `ELEVENLABS_API_KEY`
- `ELEVENLABS_VOICE_ID`
- `ELEVENLABS_MODEL_ID` (default `eleven_v3`)
- `JARVIS_ACCESS_TOKEN`

`JARVIS_ACCESS_TOKEN` is the private app password. It is never exposed to the browser. The app exchanges it for a short-lived signed HttpOnly session cookie.

## Local run

```bash
npm install
npm test
npm run dev
```

Then open the local app and enter the configured JARVIS access token.

## Browser security

`browserOpen` is deliberately restricted to `BROWSER_ALLOWED_DOMAINS`, HTTPS URLs, standard HTTPS port, non-IP hostnames, and hostnames that resolve to public addresses. This protects the Browserless backend from obvious SSRF destinations.

For a public multi-tenant product that must browse arbitrary URLs, move browser egress behind a dedicated network-isolation proxy that blocks private/reserved ranges and validates redirects. The current allowlist is the safer design for a personal JARVIS deployment.

## Rate limits

There is a per-runtime in-memory limiter on authentication, chat, and speech endpoints. For a high-traffic public deployment, add a distributed limiter and/or Vercel Firewall rules.

## Security notes

- API keys are server-only.
- Chat and speech routes require the private session cookie.
- Cross-origin POST requests are rejected.
- Request sizes are bounded.
- Tool calls inherit cancellation signals.
- Tool output is bounded before entering the model context.
- Web content and stored memory are treated as untrusted data.
