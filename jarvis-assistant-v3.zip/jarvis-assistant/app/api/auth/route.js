import {
  enforceSameOrigin,
  issueSessionCookie,
  isAuthenticated,
  readJsonBody,
  rateLimit,
  responseWithRateLimit,
  safeEqualStrings,
  setSessionCookie,
  clearSessionCookie,
  requireConfiguredAuth,
} from '../../../lib/security.js';

export const runtime = 'nodejs';

export async function GET(request) {
  const configError = requireConfiguredAuth();
  if (configError) return configError;
  return Response.json(
    { authenticated: isAuthenticated(request) },
    { headers: { 'cache-control': 'no-store' } },
  );
}

export async function POST(request) {
  const originError = enforceSameOrigin(request);
  if (originError) return originError;

  const configError = requireConfiguredAuth();
  if (configError) return configError;

  const limit = rateLimit(request, { bucket: 'auth', limit: 8, windowMs: 15 * 60 * 1000 });
  if (!limit.allowed) return responseWithRateLimit(limit.retryAfterSeconds);

  try {
    const body = await readJsonBody(request, 4_000);
    const token = typeof body?.token === 'string' ? body.token.trim() : '';

    if (!token || token.length > 256 || !safeEqualStrings(token, process.env.JARVIS_ACCESS_TOKEN)) {
      return Response.json({ error: 'Invalid access token.' }, { status: 401 });
    }

    return setSessionCookie(
      Response.json({ authenticated: true }, { headers: { 'cache-control': 'no-store' } }),
      issueSessionCookie(),
    );
  } catch (error) {
    return Response.json(
      { error: error instanceof Error ? error.message : 'Invalid request.' },
      { status: error?.status || 400 },
    );
  }
}

export async function DELETE(request) {
  const originError = enforceSameOrigin(request);
  if (originError) return originError;
  return clearSessionCookie(Response.json({ authenticated: false }));
}
