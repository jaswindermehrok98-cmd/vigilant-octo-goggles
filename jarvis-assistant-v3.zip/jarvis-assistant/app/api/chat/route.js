import { createAgentUIStreamResponse } from 'ai';
import { jarvis } from '../../../ai/agent';
import {
  enforceSameOrigin,
  rateLimit,
  readJsonBody,
  requireSession,
  responseWithRateLimit,
} from '../../../lib/security';
import { z } from 'zod';

export const runtime = 'nodejs';
export const maxDuration = 120;

const memorySchema = z.object({
  key: z.string().min(1).max(80),
  value: z.string().min(1).max(500),
  createdAt: z.string().max(64).optional(),
});

const memoryListSchema = z.array(memorySchema).max(100);

export async function POST(request) {
  const originError = enforceSameOrigin(request);
  if (originError) return originError;

  const authError = requireSession(request);
  if (authError) return authError;

  const limit = rateLimit(request, { bucket: 'chat', limit: 20, windowMs: 5 * 60 * 1000 });
  if (!limit.allowed) return responseWithRateLimit(limit.retryAfterSeconds);

  try {
    const body = await readJsonBody(request, 200_000);
    const messages = Array.isArray(body?.messages) ? body.messages.slice(-40) : null;
    if (!messages) return Response.json({ error: 'messages must be an array.' }, { status: 400 });

    const memoryResult = memoryListSchema.safeParse(body?.memory || []);
    if (!memoryResult.success) {
      return Response.json({ error: 'Invalid memory payload.' }, { status: 400 });
    }

    return createAgentUIStreamResponse({
      agent: jarvis,
      uiMessages: messages,
      options: { memory: memoryResult.data },
      abortSignal: request.signal,
      timeout: { totalMs: 115_000 },
      sendSources: true,
    });
  } catch (error) {
    const status = Number(error?.status) || 400;
    const safeMessage = status === 413 ? 'Request body too large.' : 'The agent request could not be processed.';
    return Response.json({ error: safeMessage }, { status });
  }
}
