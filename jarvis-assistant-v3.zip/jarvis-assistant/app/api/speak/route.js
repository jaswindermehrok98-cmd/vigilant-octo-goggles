import {
  enforceSameOrigin,
  rateLimit,
  readJsonBody,
  requireSession,
  responseWithRateLimit,
} from '../../../lib/security';

export const runtime = 'nodejs';
export const maxDuration = 40;

export async function POST(request) {
  const originError = enforceSameOrigin(request);
  if (originError) return originError;

  const authError = requireSession(request);
  if (authError) return authError;

  const limit = rateLimit(request, { bucket: 'speak', limit: 20, windowMs: 10 * 60 * 1000 });
  if (!limit.allowed) return responseWithRateLimit(limit.retryAfterSeconds);

  try {
    const body = await readJsonBody(request, 12_000);
    const text = typeof body?.text === 'string' ? body.text.trim().slice(0, 3_000) : '';
    if (!text) return Response.json({ error: 'Text is required.' }, { status: 400 });

    const apiKey = process.env.ELEVENLABS_API_KEY;
    if (!apiKey) return Response.json({ error: 'ElevenLabs is not configured.' }, { status: 503 });

    const voiceId = process.env.ELEVENLABS_VOICE_ID;
    if (!voiceId) return Response.json({ error: 'ELEVENLABS_VOICE_ID is not configured.' }, { status: 503 });

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30_000);
    const combinedSignal = AbortSignal.any([controller.signal, request.signal]);

    try {
      const response = await fetch(
        `https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(voiceId)}?output_format=mp3_44100_128`,
        {
          method: 'POST',
          headers: {
            'xi-api-key': apiKey,
            'content-type': 'application/json',
            accept: 'audio/mpeg',
          },
          body: JSON.stringify({
            text,
            model_id: process.env.ELEVENLABS_MODEL_ID || 'eleven_v3',
          }),
          signal: combinedSignal,
        },
      );

      if (!response.ok) {
        return Response.json({ error: `ElevenLabs request failed (${response.status}).` }, { status: 502 });
      }

      return new Response(await response.arrayBuffer(), {
        headers: {
          'content-type': response.headers.get('content-type') || 'audio/mpeg',
          'cache-control': 'no-store',
          'x-content-type-options': 'nosniff',
        },
      });
    } finally {
      clearTimeout(timeout);
    }
  } catch (error) {
    if (error?.status) return Response.json({ error: error.message }, { status: error.status });
    if (error?.name === 'AbortError' || error?.name === 'TimeoutError') {
      return Response.json({ error: 'Speech generation was cancelled or timed out.' }, { status: 504 });
    }
    return Response.json({ error: 'Speech generation failed.' }, { status: 502 });
  }
}
