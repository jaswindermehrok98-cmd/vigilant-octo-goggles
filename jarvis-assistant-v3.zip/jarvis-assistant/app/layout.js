import './globals.css';

export const metadata = {
  title: 'JARVIS — Autonomous Assistant',
  description: 'A voice-ready autonomous assistant with tool calling, web access, and a local-first interface.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
