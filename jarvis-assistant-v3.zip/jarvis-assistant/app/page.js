'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { useChat } from '@ai-sdk/react';
import { DefaultChatTransport } from 'ai';

const MAX_MEMORIES = 100;
const MAX_MEMORY_BYTES = 50_000;

function textFromMessage(message) {
  return (message?.parts || [])
    .filter((part) => part.type === 'text')
    .map((part) => part.text)
    .join('');
}

function mergeMemories(current, additions) {
  const merged = [...current];
  for (const item of additions) {
    if (!merged.some((x) => x.key === item.key && x.value === item.value)) merged.push(item);
  }

  let trimmed = merged.slice(-MAX_MEMORIES);
  while (JSON.stringify(trimmed).length > MAX_MEMORY_BYTES && trimmed.length > 1) {
    trimmed = trimmed.slice(1);
  }
  return trimmed;
}

function AuthGate({ onAuthenticated }) {
  const [token, setToken] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  async function unlock(event) {
    event.preventDefault();
    setBusy(true);
    setError('');
    try {
      const response = await fetch('/api/auth', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ token: token.trim() }),
      });
      if (!response.ok) {
        const data = await response.json().catch(() => null);
        throw new Error(data?.error || 'Authentication failed.');
      }
      onAuthenticated();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="auth-shell">
      <section className="auth-card">
        <div className="eyebrow">PRIVATE ASSISTANT</div>
        <div className="brand-mark">J</div>
        <h1>Unlock JARVIS</h1>
        <p>Enter the local access token configured for this deployment.</p>
        <form onSubmit={unlock}>
          <input
            value={token}
            onChange={(event) => setToken(event.target.value)}
            type="password"
            autoComplete="current-password"
            placeholder="Access token"
            maxLength={256}
          />
          <button type="submit" disabled={busy || !token.trim()}>
            {busy ? 'VERIFYING…' : 'UNLOCK ↗'}
          </button>
        </form>
        {error && <div className="error-box">{error}</div>}
      </section>
    </main>
  );
}

export default function Home() {
  const [authenticated, setAuthenticated] = useState(false);
  const [authChecked, setAuthChecked] = useState(false);
  const [input, setInput] = useState('');
  const [listening, setListening] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [voiceStatus, setVoiceStatus] = useState('ready');
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [memory, setMemory] = useState([]);
  const memoryRef = useRef([]);
  const statusRef = useRef('ready');
  const audioRef = useRef(null);
  const audioUrlRef = useRef(null);
  const recognitionRef = useRef(null);

  const transport = useMemo(() => new DefaultChatTransport({
    api: '/api/chat',
    credentials: 'same-origin',
    prepareSendMessagesRequest: ({ messages }) => ({
      body: {
        messages: messages.slice(-40),
        memory: memoryRef.current,
      },
    }),
  }), []);

  const { messages, sendMessage, status, stop, error, clearError } = useChat({ transport });

  useEffect(() => {
    statusRef.current = status;
  }, [status]);

  useEffect(() => {
    fetch('/api/auth', { credentials: 'same-origin' })
      .then((response) => response.json().catch(() => ({ authenticated: false })))
      .then((data) => setAuthenticated(Boolean(data?.authenticated)))
      .catch(() => setAuthenticated(false))
      .finally(() => setAuthChecked(true));
  }, []);

  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem('jarvis-memory') || '[]');
      const parsed = Array.isArray(saved) ? mergeMemories([], saved) : [];
      memoryRef.current = parsed;
      setMemory(parsed);
    } catch {
      memoryRef.current = [];
      setMemory([]);
    }
  }, []);

  useEffect(() => {
    const saved = [];
    for (const message of messages) {
      for (const part of message.parts || []) {
        if (part.type === 'tool-rememberLocally' && part.output?.memory) saved.push(part.output.memory);
      }
    }
    if (!saved.length) return;

    const merged = mergeMemories(memoryRef.current, saved);
    memoryRef.current = merged;
    setMemory(merged);
    try {
      localStorage.setItem('jarvis-memory', JSON.stringify(merged));
    } catch {
      // Keep the UI usable when browser storage is unavailable.
    }
  }, [messages]);

  function cleanupAudio() {
    try {
      audioRef.current?.pause();
    } catch {}
    audioRef.current = null;
    setSpeaking(false);
    if (audioUrlRef.current) {
      URL.revokeObjectURL(audioUrlRef.current);
      audioUrlRef.current = null;
    }
  }

  useEffect(() => {
    if (!voiceEnabled) {
      cleanupAudio();
      setVoiceStatus('ready');
      return undefined;
    }

    const lastAssistant = [...messages].reverse().find((message) => message.role === 'assistant');
    const speech = textFromMessage(lastAssistant || { parts: [] });
    if (!speech || status !== 'ready') return undefined;

    let cancelled = false;

    async function speakWithEleven() {
      setVoiceStatus('connecting');
      try {
        cleanupAudio();
        const response = await fetch('/api/speak', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          credentials: 'same-origin',
          body: JSON.stringify({ text: speech.slice(0, 3000) }),
        });
        if (!response.ok) throw new Error('Speech service unavailable.');
        const blob = await response.blob();
        if (cancelled) return;

        const url = URL.createObjectURL(blob);
        audioUrlRef.current = url;
        const audio = new Audio(url);
        audioRef.current = audio;
        audio.onplay = () => { setSpeaking(true); setVoiceStatus('speaking'); };
        audio.onended = () => { cleanupAudio(); setVoiceStatus('ready'); };
        audio.onerror = () => { cleanupAudio(); setVoiceStatus('ready'); };
        await audio.play();
      } catch {
        setSpeaking(false);
        setVoiceStatus('ready');
      }
    }

    speakWithEleven();
    return () => {
      cancelled = true;
      cleanupAudio();
    };
  }, [messages, status, voiceEnabled]);

  useEffect(() => {
    return () => {
      try {
        recognitionRef.current?.abort();
      } catch {}
      recognitionRef.current = null;
      cleanupAudio();
    };
  }, []);

  function send(text = input) {
    const clean = text.trim();
    if (!clean) return;
    if (!['ready', 'error'].includes(statusRef.current)) return;
    if (statusRef.current === 'error') clearError();
    sendMessage({ text: clean });
    setInput('');
  }

  function toggleVoiceInput() {
    if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
      setInput((value) => value || 'Voice input is not supported in this browser.');
      return;
    }
    if (listening) {
      recognitionRef.current?.stop();
      return;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.lang = 'en-IN';
    recognition.interimResults = false;
    recognition.continuous = false;
    recognition.onstart = () => setListening(true);
    recognition.onend = () => setListening(false);
    recognition.onerror = () => setListening(false);
    recognition.onresult = (event) => {
      const transcript = event.results?.[0]?.[0]?.transcript?.trim() || '';
      if (!transcript) return;
      setInput(transcript);
      window.setTimeout(() => send(transcript), 0);
    };
    recognitionRef.current = recognition;

    try {
      recognition.start();
    } catch {
      setListening(false);
      recognitionRef.current = null;
    }
  }

  function clearMemory() {
    memoryRef.current = [];
    setMemory([]);
    try {
      localStorage.removeItem('jarvis-memory');
    } catch {}
  }

  if (!authChecked) {
    return <main className="auth-shell"><div className="auth-card"><div className="eyebrow">INITIALIZING</div><div className="brand-mark">J</div><h1>Loading JARVIS…</h1></div></main>;
  }

  if (!authenticated) return <AuthGate onAuthenticated={() => setAuthenticated(true)} />;

  const state = listening ? 'LISTENING' : status === 'error' ? 'ERROR' : status !== 'ready' ? 'THINKING' : speaking ? 'SPEAKING' : 'IDLE';
  const hello = messages.length === 0;

  return (
    <main className="shell">
      <aside className="rail">
        <div className="brand">J</div>
        <div className="rail-label">JARVIS</div>
        <div className="rail-spacer" />
        <button className="mini-button" onClick={clearMemory} aria-label="Clear local memory" title="Clear local memory">⌫</button>
      </aside>

      <section className="workspace">
        <header className="topbar">
          <div>
            <div className="eyebrow">AUTONOMOUS ASSISTANT</div>
            <h1>JARVIS <span>v3</span></h1>
          </div>
          <div className={`status ${state.toLowerCase()}`}><i /> {state}{voiceStatus === 'connecting' ? ' · VOICE' : ''}</div>
        </header>

        <div className="dashboard">
          <section className="reactor-card">
            <div className={`reactor ${state.toLowerCase()}`}>
              <div className="orbit orbit-a" />
              <div className="orbit orbit-b" />
              <div className="orbit orbit-c" />
              <div className="core">J</div>
            </div>
            <div className="reactor-meta">
              <div><span>MODE</span><strong>{state}</strong></div>
              <div><span>TOOLS</span><strong>06 ACTIVE</strong></div>
              <div><span>MEMORY</span><strong>{memory.length} LOCAL</strong></div>
              <div><span>VOICE</span><strong>{voiceEnabled ? 'ON' : 'OFF'}</strong></div>
            </div>
          </section>

          <section className="chat-card">
            <div className="chat-head">
              <div><strong>Command channel</strong><span>Think → act → verify</span></div>
              <div className="head-actions">
                <button className={`voice-toggle ${voiceEnabled ? 'active' : ''}`} onClick={() => setVoiceEnabled((value) => !value)}>
                  {voiceEnabled ? 'VOICE ON' : 'VOICE OFF'}
                </button>
                {status !== 'ready' && status !== 'error' && <button className="stop" onClick={stop}>STOP</button>}
              </div>
            </div>
            <div className="messages">
              {hello && (
                <div className="hero-copy">
                  <div className="kicker">PRIVATE / ONLINE</div>
                  <h2>What shall I handle?</h2>
                  <p>JARVIS can reason across tools, search the live web, browse allowlisted rendered pages, calculate, speak, and keep local memory.</p>
                  <div className="suggestions">
                    <button onClick={() => send('What time is it in India right now?')}>Current time</button>
                    <button onClick={() => send('Search the web for the latest Next.js release and tell me what changed.')}>Latest Next.js</button>
                    <button onClick={() => send('Calculate 125 * 48 + 37.')}>Calculate</button>
                  </div>
                </div>
              )}
              {messages.map((message) => {
                const text = textFromMessage(message);
                return (
                  <div key={message.id} className={`message ${message.role}`}>
                    <div className="message-label">{message.role === 'user' ? 'YOU' : 'JARVIS'}</div>
                    <div className="message-body">{text || 'Working with tools…'}</div>
                  </div>
                );
              })}
              {error && <div className="error-box">Connection error: {error.message || 'The agent could not complete the request.'} <button onClick={() => send(input)}>RETRY</button></div>}
            </div>
            <form className="composer" onSubmit={(event) => { event.preventDefault(); send(); }}>
              <button type="button" className={`voice-button ${listening ? 'active' : ''}`} onClick={toggleVoiceInput} title="Voice input">⌁</button>
              <input
                value={input}
                onChange={(event) => setInput(event.target.value.slice(0, 12000))}
                placeholder="Tell JARVIS what to do…"
                autoComplete="off"
                maxLength={12000}
              />
              <button className="send-button" type="submit" disabled={!['ready', 'error'].includes(status) || !input.trim()}>SEND ↗</button>
            </form>
          </section>
        </div>

        <footer className="footer-note">Server APIs require the private session cookie. Gemini, Tavily, Browserless, and ElevenLabs keys stay server-side.</footer>
      </section>
    </main>
  );
}
