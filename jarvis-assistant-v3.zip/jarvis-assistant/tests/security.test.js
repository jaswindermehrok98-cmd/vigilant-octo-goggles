import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluateArithmetic } from '../lib/calculator.js';
import { isPrivateIp, validateBrowserUrl } from '../lib/browser-security.js';
import { enforceSameOrigin, readJsonBody } from '../lib/security.js';
import { issueSessionCookie, verifySessionCookie, safeEqualStrings } from '../lib/security.js';

process.env.JARVIS_ACCESS_TOKEN = 'test-secret-token-123456789';

test('calculator handles normal arithmetic', () => {
  assert.equal(evaluateArithmetic('125 * 48 + 37'), 6037);
  assert.equal(evaluateArithmetic('-10 + 5 * 2'), 0);
  assert.equal(evaluateArithmetic('(2 + 3) * 4'), 20);
});

test('calculator rejects malformed or dangerous input', () => {
  assert.throws(() => evaluateArithmetic('1 / 0'), /Division by zero/);
  assert.throws(() => evaluateArithmetic('process.exit()'));
  assert.throws(() => evaluateArithmetic('2 ** 10'));
});

test('session cookies verify and tampering fails', () => {
  const cookie = issueSessionCookie();
  assert.equal(verifySessionCookie(cookie), true);
  assert.equal(verifySessionCookie(`${cookie}x`), false);
});

test('secret comparison is stable', () => {
  assert.equal(safeEqualStrings('abc', 'abc'), true);
  assert.equal(safeEqualStrings('abc', 'abd'), false);
});


test('private IP detection blocks dangerous destinations', () => {
  assert.equal(isPrivateIp('127.0.0.1'), true);
  assert.equal(isPrivateIp('10.0.0.10'), true);
  assert.equal(isPrivateIp('192.168.1.20'), true);
  assert.equal(isPrivateIp('169.254.169.254'), true);
  assert.equal(isPrivateIp('8.8.8.8'), false);
  assert.equal(isPrivateIp('::1'), true);
});

test('browser allowlist rejects unsafe schemes and hosts', async () => {
  process.env.BROWSER_ALLOWED_DOMAINS = 'example.com';
  await assert.rejects(() => validateBrowserUrl('http://example.com'), /HTTPS/);
  await assert.rejects(() => validateBrowserUrl('https://localhost'), /private/i);
  await assert.rejects(() => validateBrowserUrl('https://127.0.0.1'), /IP-literal/);
  await assert.rejects(() => validateBrowserUrl('https://example.net'), /allowlist/);
});

test('same-origin protection rejects foreign origins', () => {
  const request = new Request('https://jarvis.test/api/chat', {
    method: 'POST',
    headers: { origin: 'https://evil.test' },
  });
  const response = enforceSameOrigin(request);
  assert.equal(response.status, 403);
});

test('request body limits work with streamed requests', async () => {
  const request = new Request('https://jarvis.test/api/x', {
    method: 'POST',
    body: JSON.stringify({ text: 'hello' }),
    headers: { 'content-type': 'application/json' },
  });
  const body = await readJsonBody(request, 1000);
  assert.equal(body.text, 'hello');
});

test('auth route sets an HttpOnly session cookie for the correct token', async () => {
  const { POST: login } = await import('../app/api/auth/route.js');
  const request = new Request('https://jarvis.test/api/auth', {
    method: 'POST',
    headers: { origin: 'https://jarvis.test', 'content-type': 'application/json' },
    body: JSON.stringify({ token: process.env.JARVIS_ACCESS_TOKEN }),
  });
  const response = await login(request);
  assert.equal(response.status, 200);
  assert.match(response.headers.get('set-cookie') || '', /HttpOnly/);
  assert.match(response.headers.get('set-cookie') || '', /SameSite=Strict/);
});
